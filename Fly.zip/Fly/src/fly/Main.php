<?php

namespace Fly; 

use pocketmine\plugin\PluginBase;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;

class Main extends PluginBase{
    
    public function onEnable(): void{
        $this->getLogger()->info("Plugin Attivo!");
    }
    
   
   public function onCommand(CommandSender $sender,Command $cmd, string $label, array $args):  bool{
       if($sender instanceof Player)
       switch($cmd->getName()) {
         case "fly":
             if($sender->getAllowFlight()===false){
                 $sender->setFlying(true);
                 $sender->setAllowFlight(true);
                 $sender->sendMessage("§aHai attivato la fly!.");
             }else{
                 $sender->setFlying(false);
                 $sender->setAllowFlight(false);
                 $sender->sendMessage("§cHai disattivato la fly!.");
             }
       }
       return true;
   }

}